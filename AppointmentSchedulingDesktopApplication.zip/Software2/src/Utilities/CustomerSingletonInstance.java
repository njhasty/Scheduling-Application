package Utilities;

// Create customer instance of application use

public class CustomerSingletonInstance {

    public static int instanceId;

}
